import qrcode
import base64
from io import BytesIO

def makecode(url:str):
  
  qr = qrcode.QRCode()
  
  qr.add_data(url)
  
  img = qr.make_image()

  buffer = BytesIO()
  img.save(buffer, format="PNG")

  return base64.b64encode(buffer.getvalue()).decode("utf-8")